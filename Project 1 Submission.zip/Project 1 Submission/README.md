# Project-1-ML-AICrowd
CS-433 ML EPFL Project 1 AI crowd competition

Bartlomiej Binda, Clement Petit, Yanis Berkani


## Architecture of the code
For this project, we used Jupyter notebook.

The main file is run.py, from which the code can be run.

The additional files are the following :

- implementations.py : contains the 6 methods to implement, along with their helper functions.
- clean_data.py : contains the code for cleaning the data.
- split_expand_data.py : contains the code for splitting and expanding the data.
- proj1_helpers.py : contains some provided code for loading data, creating submission, and predicting labels.

These files are imported in run.py.

## Running the code
The files "train.csv" and "test.csv" must be put in the same folder than run.py, along with the 4 additional files.

As written above, the code for obtaining the predictions can simply be run from run.py. This script prints the accuracy and creates a file "submission.csv" at the same folder than run.py.